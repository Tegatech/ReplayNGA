<!-- Footer -->
	<footer id="footer" >
	<div class="footer-top">
      <div class="container-fluid">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>Replay</h3>
            <p>Cras fermentum odio eu feugiat lide par naso tierra. Justo eget nada terra videa magna derita valies darta donna mare fermentum iaculis eu non diam phasellus. Scelerisque felis imperdiet proin fermentum leo. Amet volutpat consequat mauris nunc congue.</p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="ion-ios-arrow-right"></i> <a href="home.php">Home</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="about.php">About us</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">How to become a contributor</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Privacy policy</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Upload Media</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Contact Us</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Become an Affiliate</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              London | Lagos | Dallas <br>
              <!-- <strong>Phone:</strong> +1 5589 55488 55<br> -->
              <strong>Email:</strong> info@ReplayNGA.com<br>
            </p>

            <div class="social-links">
              <a href="https://twitter.com/ReplayNGA" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="https://www.instagram.com/replaynga" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="https://soundcloud.com/user-957014630" class="soundcloud"><i class="fa fa-soundcloud"></i></a>
            </div>

          </div>

          <div class="col-lg-3 col-md-6 footer-newsletter">
            <h4>Our Newsletter</h4>
            <p>Subscribe to our newsletter to get the latest Music, Videos, Events and much more</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit"  value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>
		
			<div class="container-fluid">
				
				<p class="text-center">Copyright &copy; tjoghoro 2019. All rights reserved.</p>
			</div>
		</footer>	
</body>




</html>