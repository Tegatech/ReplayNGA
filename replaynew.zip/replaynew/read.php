<?php include 'header.php'; ?>

<section class="container">
	<div class="row"> 

		<div class="col-md-8"> 
			<img src = "image/basketball.jpg" style="height: 500px; width: 100%;">
				
				<h2><strong> UK Rap Star Fredo Isn’t Resting On His Laurels </strong></h2>
		</div>

		<div class="col-md-4"> 
			<div class="row">
				
			</div>

			<div class="row">
				
			</div>

			<div class="row">
				
			</div>

		</div>

	</div>

</section>