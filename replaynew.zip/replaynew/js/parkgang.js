$(document).ready(function()
		{
			$('#loading').fadeOut('slow');
	});