<!DOCTYPE html>
<html>
<head>
	<title>Replay Media: Hub of the yutes</title>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">

	 <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

   <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">



    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="bootstrap/css/bootstrap.css">

	<!-- CSS Stylesheet -->
	<link rel="stylesheet" href="style.css">
	<script type="text/javascript" src="bootstrap/js/jquery-3.1.1.js"></script>


  <script type="text/javascript" src="js/parkgang.js"></script> 

</head>

<!-- BODY -->
<body>
  <div id="loading"> </div>
	<header  id="header">
	<div class="container-fluid">

      <div id="logo" class="pull-left">
        <h1><a href="#intro" class="scrollto">REPLAY</a></h1>
      </div>

    
      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <!-- <li><a href="read.php">READ</a></li> -->
          <li><a href="radio.php">REPLAY RADIO</a></li>
          <li><a href="tv.php">REPLAYTV</a></li>
          <!-- <li class="menu-has-children"><a href="radio.php">Replay Radio</a>
            <ul>
              <li><a href="#">Podcasts</a></li>
              <li><a href="#">Playlist</a></li>
              <li><a href="#">Music</a></li>
            </ul>
          </li> -->
          <li><a href="magazine.php">Magazine</a></li>
           <li> <a href="#"><span id="searchicon" class="glyphicon glyphicon-search"></span></a></li>
        </ul>
      </nav>
		</div>
</header>