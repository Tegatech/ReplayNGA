<?php include "header.php"; ?>


<section style="margin-top: 100px;"> 
  <div class="container">
    <div class="row" style="margin-top: 50px;">
         <div class="col-md-7"><img src = "https://images.genius.com/d3806d5ec7b60e766d54d0ea3c1d7dd2.750x750x1.jpg"  class="img-responsive"> <br/> 
        <p> Maleek Berry has shared a new EP entitled First Daze of Winter, a six-track collection of inviting afropop compositions. The project is Berry's first since Last Daze of Summer, released in 2016. The new EP features two previously released tracks — "Been Calling" and "Pon My Mind" — as well as four new tracks. "Own It" is an immediate stand out.</p>
        </div> 

        <div class="col-md-5">
        <iframe allow="autoplay *; encrypted-media *;" frameborder="0" height="500" style="width:100%;max-width:660px;overflow:hidden;background:transparent;" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-storage-access-by-user-activation allow-top-navigation-by-user-activation" src="https://embed.music.apple.com/us/album/first-daze-of-winter-ep/1323771562"></iframe>
        </div>
    </div>

  
  </div>
</section>
