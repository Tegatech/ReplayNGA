<?php include "header.php" ?>

<!-- Release page (general) -->
<div class="container" class="text">
<section style="margin-top: 100px;">

<div class="row">

    <div class="col-md-3 col-sm-3" style="margin-top: 20px;">
          <a href="audiopage.php"><img src = "https://images.genius.com/d3806d5ec7b60e766d54d0ea3c1d7dd2.750x750x1.jpg" class="img-responsive" id="winter"></a>
         <strong> Maleek Berry | First Daze of Winter </strong>
      </div>

        
        <div class="col-md-3 col-sm-3" style="margin-top: 20px;" >
        <a href="audiopage.php"><img src = "https://images.genius.com/a6684428a77ab5490e0f09c6bdc47f96.1000x1000x1.jpg"  class="img-responsive"/></a>
       <strong> Maleek Berry | Last Daze of Summer EP </strong>
        </div>

        <div class="col-md-3 col-sm-3" style="margin-top: 20px;" >
        <a href="audiopage.php"> <img src = "https://images.genius.com/507032f5d443ebe05f1e01225cf2a18f.800x800x1.jpg"  class="img-responsive"></a>
        <strong>CHEU B | Welcome to skyland </strong>
        </div>

        <div class="col-md-3 col-sm-3" style="margin-top: 20px;" >
        <a href="audiopage.php"> <img src = "https://www.theinternationalconnect.net/wp-content/uploads/2018/06/niska-commando__933987_.jpg"  class="img-responsive"> </a>
         <strong> NISKA | MEDELLIN </strong>
        </div>
</div>

<div class="row">
        <div class="col-md-3 col-sm-3" style="margin-top: 20px;">

          <a href="audiopage.php"><img src = "https://is2-ssl.mzstatic.com/image/thumb/Music123/v4/c1/ee/a9/c1eea925-4340-7189-7d3a-07ed3d7c50d0/193483785837.jpg/600x600bf.png" class="img-responsive" id="winter"></a>
          <strong> Skepta | Ignorance is bliss </strong>
        </div>

        
        <div class="col-md-3 col-sm-3" style="margin-top: 20px;" >
        <a href="audiopage.php"><img src = "https://images.genius.com/e0e3d05e1a49fce3fd25b07758674463.960x960x1.jpg"  class="img-responsive"/></a>
         <strong> Aya Nakamura | NAKAMURA </strong>
        </div>

        <div class="col-md-3 col-sm-3" style="margin-top: 20px;" >
        <a href="audiopage.php"> <img src = "https://is2-ssl.mzstatic.com/image/thumb/Music113/v4/eb/91/5c/eb915c17-7288-896e-0ac9-3ab3eaeac0e2/075679849304.jpg/600x600bf.png"  class="img-responsive"></a>
         <strong> Burna Boy | African Giant </strong>
        </div>

        <div class="col-md-3 col-sm-3" style="margin-top: 20px;" >
        <a href="audiopage.php"> <img src = "https://is5-ssl.mzstatic.com/image/thumb/Music114/v4/ab/a4/5a/aba45a09-66c8-37c1-c850-c65c60f77310/44003187658_1.jpg/600x600bf.png"  class="img-responsive"> </a>
         <strong> Childish Gambino | Awaken, My Love! </strong>
        </div>
   </div>  

</section>
</div>

<?php include 'footer.php'; ?>