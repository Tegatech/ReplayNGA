<?php include "header.php" ?>

<section style="margin-top: 150px;" class="text">
  


  <section class="container-fluid">
    <iframe width="100%" height="500" src="https://www.youtube.com/embed/xUetSQlxOWY??autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

  </section>


  <h2 style="margin-top: 10px; text-align: center; color: black;"><strong>LATEST VIDEOS</strong></h2>
  <div class="container">
      <div class="row" style="margin-top: 10px;">

      <div class="col-md-4  col-sm-6" >
       <iframe width="100%" height="200" src="https://www.youtube.com/embed/yXrmJuitsns?start=5" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <strong>Bolemv | Sankhara</strong>
      </div>

      <div class="col-md-4  col-sm-6" >
        <iframe width="100%" height="200" src="https://www.youtube.com/embed/JEq-li_e9Fg?start=5" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
        </iframe>
        <strong>Maleek Berry | Been Calling</strong>
      </div>
      
      <div class="col-md-4  col-sm-6" >
      <iframe width="100%" height="200" src="https://www.youtube.com/embed/P2WZfd-Z2-o?start=5" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <strong> Offset x DBlock Europe | Rich </strong>
      </div>
      

      <div class="col-md-4  col-sm-6" >
       <iframe width="100%" height="200" src="https://www.youtube.com/embed/Eoyk_JEHxUQ?start=5" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <strong> Niska | Medellin </strong>
      </div>

      <div class="col-md-4  col-sm-6" >
        <iframe width="100%" height="200" src="https://www.youtube.com/embed/cHL-fNnDwU0?start=5" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
        </iframe>
        <strong> Skepta x Nafe Smallz | Greaze Mode </strong>
      </div>
      
      <div class="col-md-4 col-sm-6" >
      <iframe width="100%" height="200" src="https://www.youtube.com/embed/1ruitsqQ34c?start=5" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <strong> Yxng Bane | Rihanna </strong>
      </div>
      

      </div>
    </div>





</section>


<?php include 'footer.php'; ?>