<?php include 'header.php'; ?>

<section id="article" class="container-fluid">
	<img src = "image/basketball.jpg" style="height: 500px; width: 100%;">
</section>

	<div class="container">
		<h4 class="tag"><strong> <a href="#"> SPORT </a></strong></h4>
		<h1 class="articleh1"> TEGRITO OPENS UP ABOUT LIFE AFTER THE NBA III </h1>

		<h3>Damian Lillard speaks about the pressure of playing basketball: “Pressure is the single mom, who is trying to scuffle and pay her rent. ... In one of his interviews a couple of years back Lillard was asked about the pressure of winning basketball games and ultimately the NBA championship.</h3>

		<div class="row">
			<div class="col-md-4">
				<p> By <b>Emma Garland</b>; photos by <b>Chris Bethell</b></p>
			</div>

			<div class="col-md-4">
				
				SHARE: <span class="fa fa-facebook"> Tweet </span>

				<span class="fa fa-twitter"> Share </span> 

			</div>

			<div class="col-md-4">
				<p>02 August 2019, 12:11pm </p>
			</div>
		</div>

		<hr>

		<P class="articlep">june 27, 2019, was an important day for British rap: it was the unveiling of a new K-Trap, the unmasking of a rapper who—since his debut in 2016—had been brazenly wearing balaclavas due to not wanting none of the fame, nor the “baitness”, that came with the job. No face, no case, was fully in motion.

Twenty years after the world was introduced to the metal mask of MF Doom—the London-born, globally-revered hip-hop legend—the mid-2010s saw a new wave of masked emcees rise up from London’s inner city, whose harsh realities on wax have been a major point of contention. The UK drill scene—inspired heavily by Chicago’s “Chiraq” sound of the early 2010s, but one unique to its London-centric stomping ground—is a movement that South London-repping K-Trap feels proud to have come up in, but having been one of its leading torch-bearers (alongside Headie One), it’s now time, he feels, to explore the next chapter of his career.

On No Magic, K’s first project as a bally-free rapper—and also his first as a newly-signed artist to Sony imprint Black Butter, which follows underground smashes The Re-Up and The Last Whip—we get a K-Trap in full experimental mode, trying out his choppy, urgent flows on Afro-inspired cuts (“Young Fly”) and club-ready riddims (“Stay Safe”), all while staying true to his trap (“Gunshots”) and drilly beginnings (“Badness”). There’s even some downtempo, guitar-led R&B (“Change”) for good measure. Showing that he’s more than the trigger-happy rhymes we’ve come to know and love him for, here K-Trap gives us introspection from a fly-boy’s perspective while also nodding to his days in the trap and his love of the hustle.

In his first interview as an unmasked artist, Complex gets the lowdown on K-Trap.

“IT’S DIFFICULT BECAUSE EVERYBODY KNOWS WHO I AM, SO I HAVE TO KEEP THAT MOOD AND THAT IMAGE EVERY SECOND NOW.”
I remember talking to your manager, Ebi, like six months ago, when all the labels were bidding for you, and I’m glad to see that you went with Black Butter; their success rate with UK talent is up there right now. How have you found that transition from indie act to signed artist?

It’s been alright, you know. Obviously, I’ve had to adapt to a lot of stuff. I’m mad impatient, so signing to a label is… it’s not so much moving at their time but it just has to go by the books. That was very difficult for me, but I feel like I’m starting my journey properly now. 

What was the first thing you bought with your advance?

To be honest, nothing. I dunno; everything you’d think would be on the way, I already had, so it’s mostly been just upgrading a few things. You have to be level-headed with these things though. Money comes and goes too quick, so you have to know what you’re doing with it.

So, K-Trap: who is he, where’s he from, and what motivates him?

I’d call myself a trap artist that does a bit of drill. When I first came through, I was more drill than trap. I’m from South London, Gypsy Hill, and I’ve been rapping from a young age. I went through loads of hurdles in life where I wasn’t really ready; to be honest, I’m getting there but I’ve never been too much of a people person. I’m just not that social, and I’ve never really wanted the fame that comes with being a rapper. I found it hard to handle that kind of attention; I’m a bit more reserved than that. Being a rapper and doing what I’m doing now is a big thing. I wasn’t really ready for it for a long time. I didn’t start properly rapping and taking it seriously until around 2015, but then I got into some trouble: I got found not guilty on a case that was pending for about two years, and that was holding me back. That made me not want to rap and make anything worse. When I got found not guilty for that, I started rapping but I still didn’t want too much heat so I put a bally on, tried it, and it just went mad.

How did you find it being a masked emcee? When you had the bally on, you’re seeing everything—all the hype you’re creating—but people can’t see who you really are. When everything was blowing up, how did that make you feel? 

Looking back, having that bally on was good. The position I was in—like you said, I was seeing everything around me so it was up to me what I wanted to do with that attention. At the same time, I felt like where I want to get to in music, the road I’m heading down, a bally’s not really accepted that much. People always used to say to me, “Be the first person with a bally to do this.” I’m not passionate about wearing the bally, though, so taking it to that high, high level that people thought I could was good for me.

All throughout 2018, we saw how the disconnected media threw blame on UK drill for the rise in youth violence, which we both know is a lot deeper than just beats and rhymes. When all of that was going on, what was going through your mind, and is any of that the reason behind you giving up the mask?

If I’m honest, no. When all the backlash was going on, it didn’t really touch me. I obviously didn’t like the negativity on drill itself, but me personally, as an artist, I don’t feel like them cracking down on drill had a major affect on what I was doing. I didn’t feel like I was targeted like certain other artists were getting targeted.

On a personal level, has freeing the bally set you free? I saw you at #Merky Festival living your best life! [Laughs] But how’s it been having everyone know what you look like now? 

It’s kinda difficult. Like you said, you saw me at #Merky; since #Merky, I’ve kinda been hiding away [laughs]. Not hiding away, but I haven’t really been anywhere like that, so I’m still not really seeing what’s going on. But yeah, it’s difficult because everybody knows who I am so I have to keep that mood and that image every second now. 

“THE MAIN THING THAT MUSIC HAS DONE IS IT’S GIVEN ME SOMETHING POSITIVE TO DO AND TO SHARE WITH MY FAMILY.”
k-trap
How would you say that music’s changed your life? Has it changed your life? 

Yeah, it definitely has. The main thing that music has done is it’s given me something positive to do and to share with my family. I can actually stop and have a chat with somebody and if they ask me what I do, I can actually say something and be proud of it. That’s one. And I feel like a lot of people downplay it financially—that’s definitely changed man’s life. It’s helped to keep me from certain other activities, and it does pay good. I enjoy music a lot, and it’s definitely bettering my life and keeping me out of certain situations. 

How would you say South London has impacted you as an artist, as a man? It’s like its own little island. 

I don’t know how to explain it... One thing I’d say about South London is, God willing, when man does properly make it out, I feel like coming from South—and not to say that East, West and North aren’t doing their thing—but coming from South and actually doing something good, because there’s loads of bad influences, it’s a proper big deal and people are proud of you for real.

You’ve got a strong bond with fellow South London rapper Blade Brown. Tell us how that connection came about.

Yeah, Blade’s my bro. I used to see Blade a lot when I was growing up. I’ve always fucked with him, from early—I’ve always thought that he was hard. I used to see him and hit him up, or he’d hit me up. One time, I think when he was working on something, we just linked up and patterned up. But yeah, Blade’s a good brother. Even when I first met him, I came to realise he knew loads of family and stuff and the link was just better.

Have you found other people in the industry have warmed to you in the same way?

Yeah, it’s all love. There are certain people who’ve shown me genuine, actual love, and I can see that they fuck with me hard. Nobody’s shown me any negativity other than those fake ones, but there’s some real people in the music industry at the same time.

I’ve always said that you and Headie One, specifically, would take UK drill to the next level; you both showed your versatility early on. Would you consider yourself a drill artist today, though?

I wouldn’t say I’m a drill artist, and if I was going to say I’m a drill artist, it’s hard to explain. I was a drill artist when drill first started and I was making drill. But drill now, I wouldn’t class myself in that category.

I think your rhyming patterns will forever link back to drill’s DNA, but your content and the beats you’re lacing now, you’re just tapping into your artistry more. 

Yeah, definitely. To be honest, I’m not really fussed. I’m not trying to disown drill because drill was definitely a big part of man. Me, as an artist, and me knowing myself, I can do loads of different types of music, but I rap what I live. At the beginning, it was loads of drill and then trap. It’s just different.

From The Last Whip to The Re-Up to No Magic, how would you say you’ve grown as a lyricist? Has it been the rhyme schemes, the lyrical content?

I feel like The Last Whip, that was just trap. That was just me doing whatever. With The Re-Up, I feel like I put a bit more time and effort into it, but it was still me, if you get me? I tried to do it a little bit different. No Magic now, that’s me throwing myself into the deep end where I can make something different, try new things and cater to a wider range of people.

Do you have a favourite track on No Magic? Mine would have to be “Stay Safe”, the track with Donae’O. I didn’t expect that one at all, but it just worked. 

Yeah, my favourite track is “Change”. It’s just real life! When man start doing proper stuff, and you’re from the hood, certain times people make you feel like you’re doing the wrong thing. When I heard that beat, I literally made the song that same day. I didn’t come back to it, I didn’t work on it, it just came out. It was real stuff that was coming out.

“THERE’S STILL A BIT MORE FINDING MY FEET IN CERTAIN ASPECTS, BUT I FEEL LIKE I’M HEADING IN THE RIGHT DIRECTION.” <P>


	<div class="row">
			<div class="col-md-6">
				<img src = "image/blog/fatima.jpg" style="height: 350px; width: 100%;">
				<h4><strong> Fatima bakes the first cookie in </strong></h4>
			</div>

			<div class="col-md-6">
				<img src = "image/blog/guess.jpg" style="height: 350px; width: 100%;">
				<h4><strong> Bunch of mandem on a bridge innit</strong></h4>
			</div>
		</div>
</div>


<?php include 'footer.php'; ?>