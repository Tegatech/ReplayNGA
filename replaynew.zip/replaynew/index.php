<?php include 'header.php'; ?>


<div id="intro" class="container">
	<section class="row">
		<a href="article.php">
			<div class="row col-md-12">
				<img src = "image/basketball.jpg" style="height: 500px; width: 100%;">
				
				<h2><strong> UK Rap Star Fredo Isn’t Resting On His Laurels </strong></h2>
			</div>
		</a>

		<div class="row">
			<div class="col-md-6">
				<img src = "image/blog/fatima.jpg" style="height: 350px; width: 100%;">
				<h4><strong> Fatima bakes the first cookie in </strong></h4>
			</div>

			<div class="col-md-6">
				<img src = "image/blog/guess.jpg" style="height: 350px; width: 100%;">
				<h4><strong> Bunch of mandem on a bridge innit</strong></h4>
			</div>
		</div>


	</section>
</div>

<?php include 'footer.php'; ?>

























</body>
</html>