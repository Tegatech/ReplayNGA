<?php include 'header.php'; ?>

<section style="margin-top: 90px;"> 
  <div class="container-fluid">
    <div class="row">
        <img src="image/replay2.jpg" class="img-responsive">
        
    </div> 
  </div>
</section>